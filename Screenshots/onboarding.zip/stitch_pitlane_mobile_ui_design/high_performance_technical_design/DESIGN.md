---
name: High-Performance Technical Design
colors:
  surface: '#111413'
  surface-dim: '#111413'
  surface-bright: '#373a38'
  surface-container-lowest: '#0c0f0d'
  surface-container-low: '#191c1b'
  surface-container: '#1d201f'
  surface-container-high: '#282b29'
  surface-container-highest: '#333534'
  on-surface: '#e2e3e0'
  on-surface-variant: '#c0c9c3'
  inverse-surface: '#e2e3e0'
  inverse-on-surface: '#2e312f'
  outline: '#8a938e'
  outline-variant: '#404945'
  surface-tint: '#9ed1bd'
  primary: '#9ed1bd'
  on-primary: '#00382a'
  primary-container: '#1b4d3e'
  on-primary-container: '#8abda9'
  inverse-primary: '#376757'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#fab6ac'
  on-tertiary: '#4e241e'
  tertiary-container: '#673831'
  on-tertiary-container: '#e4a399'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#baeed9'
  primary-fixed-dim: '#9ed1bd'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#1d4f40'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#fab6ac'
  on-tertiary-fixed: '#34100b'
  on-tertiary-fixed-variant: '#693a33'
  background: '#111413'
  on-background: '#e2e3e0'
  surface-variant: '#333534'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 16px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for the high-velocity world of motorsports and technical performance. It evokes the atmosphere of a night race—where precision instruments meet the darkness of the track. The aesthetic is a fusion of **Corporate Modern** and **Futuristic Technical**, prioritizing rapid data legibility and high-visibility accents.

The brand personality is authoritative and disciplined. It avoids the aggressive "red" tropes of racing in favor of a sophisticated, technology-led palette. The UI should feel like a premium Head-Up Display (HUD): lean, focused, and exceptionally responsive.

## Colors
The palette is anchored by **Racing Green**, a deep, saturated forest tone that provides a grounded, professional foundation. This is contrasted by **Electric Cyan**, a high-visibility accent that draws the eye to critical actions and data points.

To ensure WCAG AA compliance on dark surfaces:
- **Surface Base**: A deep, desaturated charcoal with a green undertone to maintain harmony.
- **Primary Text**: Off-white for maximum contrast without the harshness of pure white.
- **Secondary/Muted Text**: Lightened to a medium-gray with teal undertones to ensure legibility while maintaining hierarchy.
- **Accents**: Cyan is reserved for interactive states, progress indicators, and "active" telemetry.

## Typography
The typographic system utilizes **Space Grotesk** for headings to provide a geometric, technical character reminiscent of instrument clusters. For body copy and data, **Geist** provides a highly legible, monospaced-adjacent feel that excels in dense information environments.

All labels use a slight tracking (letter-spacing) increase and uppercase styling to mimic technical specifications and engineering blueprints. High-contrast ratios are strictly maintained for all body and label roles.

## Layout & Spacing
The layout follows a strict 12-column **Fixed Grid** on desktop, transitioning to a fluid single-column layout on mobile. The spacing rhythm is based on a 4px baseline grid, ensuring mathematical precision in element alignment.

- **Desktop**: 24px gutters with 64px outer margins to allow the content room to breathe amidst high-density data.
- **Mobile**: Margins compress to 16px.
- **Density**: The design system favors a "compact" density model for data-heavy views (telemetry, lap times) and a "comfortable" model for editorial or settings views.

## Elevation & Depth
Depth is communicated through **Tonal Layering** rather than traditional shadows. Surfaces "lift" by becoming slightly lighter and more vibrant versions of the base Racing Green.

- **Level 0 (Base)**: Deepest green-black (#0D1110).
- **Level 1 (Cards/Sections)**: Dark Racing Green (#161D1B).
- **Level 2 (Popovers/Modals)**: Medium Racing Green (#1F2926) with a 1px low-opacity Cyan stroke.

Subtle backdrop blurs (Glassmorphism) are used for global navigation bars to maintain a sense of environmental awareness as the user scrolls.

## Shapes
The shape language is **Soft (0.25rem)**. This subtle rounding provides a modern, engineered feel that avoids the "playfulness" of high-radius corners while feeling more sophisticated than sharp 0px corners.

- **Buttons & Inputs**: 4px (0.25rem) radius.
- **Containers**: 8px (0.5rem) radius.
- **Interactive Indicators**: Pill-shaped for toggle switches only.

## Components
### Buttons
Buttons are the primary vehicle for the Electric Cyan accent. 
- **Primary**: Solid Electric Cyan background with black text for maximum visibility. No gradients.
- **Secondary**: Racing Green background with a 1px Cyan border.
- **Ghost**: Ghostly Cyan text with no background; background appears at 10% opacity on hover.

### Inputs & Fields
Input fields use the Surface Container color with a subtle 1px border that glows Electric Cyan upon focus. Error states should use a high-visibility Yellow (#FFD600) instead of red to maintain the unique color identity of the design system.

### Cards & Telemetry
Data cards should use a flat background (Level 1) with "Racing Green" accents for headers. Use monospaced numerical sets within Geist to ensure tabular data aligns perfectly across rows.

### Chips & Status
Status indicators should be minimal. "Active" or "Live" states use the Electric Cyan with a subtle outer glow (0-0-8px) to simulate a powered LED.